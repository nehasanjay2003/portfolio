/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  darkMode: "media",
  theme: {
    extend: {
      colors: {
        paper: "var(--paper)", ink: "var(--ink)", muted: "var(--muted)",
        line: "var(--line)", canopy: "var(--canopy)", signal: "var(--signal)", card: "var(--card)",
      },
      fontFamily: {
        display: ['"Avenir Next"', "Avenir", "Segoe UI", "Helvetica Neue", "system-ui", "sans-serif"],
        body: ["system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
      },
    },
  },
  plugins: [],
};
