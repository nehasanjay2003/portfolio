# neha-s-data-portfolio

Suggested GitHub repository name: `neha-s-data-portfolio`

## Overview
A one-page portfolio for Neha S, an M.Sc. Data Science and Analytics graduate targeting data analyst, data science and ML roles. The design draws on her strongest work: a canopy-height chart in the hero, the U-Net / ViT research project featured first, then three dashboard and modelling projects. Light and dark themes follow the system setting.

## Tech stack
Next.js 14 (App Router), React 18, Tailwind CSS 3. No API keys or environment variables.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000. For a production check: `npm run build && npm start`.

## Customize
- All text, links, projects, skills and certifications: `data/content.js`
- Colors (light and dark): CSS variables at the top of `app/globals.css`
- Layout and section order: `app/page.jsx`
- Components: `components/`

## Details to verify before publishing
- LinkedIn: the resume lists `linkedin.com/in/neha-s`, the LinkedIn PDF shows `/in/nehas-48067b335`. The site uses the latter; change `profile.linkedin` if needed.
- The Healthcare dashboard GitHub link was reconstructed from the resume text (`Healthcare-Analytics-Dashboard`); confirm the repository URL.
- The hero chart is illustrative artwork, not real model output. Only the RMSE (2.43 m) and R² (0.88) figures are real.

## Structure
```
neha-s-data-portfolio/
├── app/ (layout.jsx, page.jsx, globals.css)
├── components/ (Nav, Hero, CanopyChart, Section, Projects)
├── data/content.js
├── package.json, next.config.js, tailwind.config.js, postcss.config.js
└── README.md
```
