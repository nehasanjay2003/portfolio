function Tags({ items }) {
  return (
    <ul className="mt-4 flex flex-wrap gap-2">
      {items.map((t) => (
        <li key={t} className="rounded border border-line px-2 py-0.5 text-xs text-muted">{t}</li>
      ))}
    </ul>
  );
}

function Row({ label, children }) {
  return (
    <div className="grid gap-1 sm:grid-cols-[7rem_1fr]">
      <dt className="text-sm font-semibold">{label}</dt>
      <dd className="text-sm text-muted">{children}</dd>
    </div>
  );
}

export function FeaturedProject({ p }) {
  return (
    <article className="rounded-xl border border-canopy bg-card p-6 md:p-8">
      <h3 className="font-display text-xl font-semibold">{p.name}</h3>
      <p className="mt-1 text-sm text-muted">{p.kind}</p>
      <dl className="mt-6 space-y-3">
        <Row label="Problem">{p.problem}</Row>
        <Row label="Solution">{p.solution}</Row>
        <Row label="My role">{p.contribution}</Row>
        <Row label="Outcome">{p.outcome}</Row>
      </dl>
      <Tags items={p.tech} />
    </article>
  );
}

export function ProjectCard({ p }) {
  return (
    <article className="flex flex-col rounded-xl border border-line bg-card p-6 transition-colors hover:border-canopy">
      <h3 className="font-display text-lg font-semibold">{p.name}</h3>
      <p className="text-xs text-muted">{p.year}</p>
      <dl className="mt-4 flex-1 space-y-3">
        <Row label="Problem">{p.problem}</Row>
        <Row label="Solution">{p.solution}</Row>
        <Row label="Outcome">{p.outcome}</Row>
      </dl>
      <Tags items={p.tech} />
      <a href={p.link} target="_blank" rel="noreferrer" className="mt-5 text-sm font-semibold text-canopy underline underline-offset-4">View on GitHub</a>
    </article>
  );
}
