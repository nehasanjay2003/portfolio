// Decorative canopy-height profile (illustrative shape only, not real data).
const heights = [30, 46, 38, 62, 84, 70, 92, 66, 78, 54, 68, 44, 58, 36, 48, 28];

export default function CanopyChart() {
  const w = 16 * 22;
  const pts = heights.map((h, i) => `${i * 22 + 9},${120 - h * 1.05 + (i % 3) * 3}`).join(" ");
  return (
    <figure aria-label="Illustrative canopy height profile: bars for LiDAR reference, line for model prediction">
      <svg viewBox={`0 0 ${w} 130`} className="w-full" role="img">
        {heights.map((h, i) => (
          <rect key={i} className="bar" style={{ animationDelay: `${i * 45}ms` }}
            x={i * 22 + 3} y={120 - h * 1.05} width="12" height={h * 1.05} rx="2" fill="var(--canopy)" opacity="0.85" />
        ))}
        <polyline points={pts} fill="none" stroke="var(--signal)" strokeWidth="2.5" strokeLinejoin="round" />
        <line x1="0" y1="120.5" x2={w} y2="120.5" stroke="var(--line)" />
      </svg>
      <figcaption className="mt-3 flex gap-5 text-xs text-muted">
        <span className="flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-sm bg-canopy" />LiDAR reference</span>
        <span className="flex items-center gap-2"><i className="h-0.5 w-4 bg-signal" />Model prediction (illustrative)</span>
      </figcaption>
    </figure>
  );
}
