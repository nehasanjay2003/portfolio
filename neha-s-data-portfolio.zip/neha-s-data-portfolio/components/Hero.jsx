import CanopyChart from "./CanopyChart";

export default function Hero({ profile, metrics }) {
  return (
    <section id="top" className="mx-auto grid max-w-5xl items-center gap-12 px-6 pb-12 pt-16 md:grid-cols-2 md:pt-24">
      <div>
        <p className="text-sm text-muted">{profile.name}, {profile.title}</p>
        <h1 className="mt-4 font-display text-4xl font-bold leading-[1.1] tracking-tight md:text-5xl">
          {profile.headline}
        </h1>
        <p className="mt-5 max-w-md text-muted">{profile.tagline}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#work" className="rounded-md bg-canopy px-5 py-2.5 text-sm font-semibold text-paper transition-transform hover:-translate-y-0.5">See my work</a>
          <a href="#contact" className="rounded-md border border-line px-5 py-2.5 text-sm font-semibold transition-colors hover:border-canopy">Get in touch</a>
        </div>
      </div>
      <div className="rounded-xl border border-line bg-card p-6">
        <CanopyChart />
        <dl className="mt-5 flex gap-8 border-t border-line pt-4">
          {metrics.map((m) => (
            <div key={m.label}>
              <dd className="font-display text-2xl font-bold text-canopy">{m.value}</dd>
              <dt className="text-xs text-muted">{m.label} on canopy height estimation</dt>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
