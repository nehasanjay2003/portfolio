const links = [["About", "#about"], ["Work", "#work"], ["Experience", "#experience"], ["Skills", "#skills"], ["Contact", "#contact"]];

export default function Nav({ name }) {
  return (
    <header className="sticky top-0 z-10 border-b border-line bg-paper/90 backdrop-blur">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-6 py-3" aria-label="Main">
        <a href="#top" className="font-display font-semibold">{name}</a>
        <ul className="hidden gap-6 text-sm text-muted sm:flex">
          {links.map(([l, h]) => (
            <li key={h}><a className="transition-colors hover:text-ink" href={h}>{l}</a></li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
