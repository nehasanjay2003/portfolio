import Nav from "../components/Nav";
import Hero from "../components/Hero";
import Section from "../components/Section";
import { FeaturedProject, ProjectCard } from "../components/Projects";
import { profile, about, featured, projects, experience, skills, education, certifications } from "../data/content";

export default function Home() {
  return (
    <>
      <Nav name={profile.name} />
      <main>
        <Hero profile={profile} metrics={featured.metrics} />

        <Section id="about" title="About">
          <div className="max-w-2xl space-y-4 leading-relaxed text-muted">
            {about.map((t) => <p key={t}>{t}</p>)}
          </div>
        </Section>

        <Section id="work" title="Selected work">
          <div className="space-y-6">
            <FeaturedProject p={featured} />
            <div className="grid gap-6 md:grid-cols-3">
              {projects.map((p) => <ProjectCard key={p.name} p={p} />)}
            </div>
          </div>
        </Section>

        <Section id="experience" title="Experience">
          {experience.map((e) => (
            <article key={e.role} className="border-l-2 border-canopy pl-6">
              <h3 className="font-display text-lg font-semibold">{e.role}, {e.org}</h3>
              <p className="text-sm text-muted">{e.dates}</p>
              <ul className="mt-4 max-w-2xl list-disc space-y-2 pl-5 text-sm text-muted">
                {e.points.map((p) => <li key={p}>{p}</li>)}
              </ul>
            </article>
          ))}
        </Section>

        <Section id="skills" title="Skills">
          <dl className="grid gap-6 sm:grid-cols-2">
            {skills.map((s) => (
              <div key={s.group}>
                <dt className="font-display font-semibold">{s.group}</dt>
                <dd className="mt-2 flex flex-wrap gap-2">
                  {s.items.map((i) => <span key={i} className="rounded border border-line bg-card px-2.5 py-1 text-sm text-muted">{i}</span>)}
                </dd>
              </div>
            ))}
          </dl>
        </Section>

        <Section id="education" title="Education and certifications">
          <div className="grid gap-10 md:grid-cols-2">
            <ul className="space-y-5">
              {education.map((e) => (
                <li key={e.name}>
                  <p className="font-semibold">{e.name}</p>
                  <p className="text-sm text-muted">{e.org}, {e.dates}</p>
                  <p className="text-sm text-muted">{e.note}</p>
                </li>
              ))}
            </ul>
            <ul className="space-y-5">
              {certifications.map((c) => (
                <li key={c.name}>
                  <p className="font-semibold">{c.name}</p>
                  <p className="text-sm text-muted">{c.org}, {c.year}</p>
                </li>
              ))}
            </ul>
          </div>
        </Section>

        <Section id="contact" title="Contact">
          <p className="max-w-lg text-muted">{profile.openTo}</p>
          <a href={`mailto:${profile.email}`} className="mt-6 inline-block font-display text-2xl font-semibold text-canopy underline underline-offset-4 md:text-3xl">{profile.email}</a>
          <ul className="mt-6 flex flex-wrap gap-6 text-sm">
            <li><a className="underline underline-offset-4" href={`tel:${profile.phone.replace(/-/g, "")}`}>{profile.phone}</a></li>
            <li><a className="underline underline-offset-4" href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn</a></li>
            <li><a className="underline underline-offset-4" href={profile.github} target="_blank" rel="noreferrer">GitHub</a></li>
          </ul>
        </Section>
      </main>
      <footer className="border-t border-line py-8 text-center text-sm text-muted">
        {profile.name}, {profile.location}
      </footer>
    </>
  );
}
