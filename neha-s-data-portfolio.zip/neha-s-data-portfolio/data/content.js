// All portfolio content lives here. Edit this file to update the site.
// Every item comes from the resume and LinkedIn profile; nothing is invented.

export const profile = {
  name: "Neha S",
  title: "Data Science & Analytics Postgraduate",
  headline: "I turn raw records and imagery into models and dashboards people can act on.",
  tagline:
    "M.Sc. Data Science and Analytics graduate with research experience in PyTorch deep learning and hands-on work in SQL, Power BI and Tableau.",
  location: "Kerala, India",
  openTo: "Open to data analyst, data science and machine learning roles across India.",
  email: "nehasanjay2003@gmail.com",
  phone: "+91-6282532704",
  linkedin: "https://www.linkedin.com/in/nehas-48067b335",
  github: "https://github.com/nehasanjay2003",
};

export const about = [
  "I completed my M.Sc. in Data Science and Analytics at Mahatma Gandhi University, Kottayam, graduating with 85% and placing 4th in my program.",
  "My most recent work was a research internship at Digital University Kerala, where I built U-Net and Vision Transformer models to estimate forest canopy height from aerial images. Alongside that, I build dashboards in SQL Server, Power BI and Tableau that turn large tables into clear KPIs.",
];

export const featured = {
  name: "Forest Canopy Height Estimation",
  kind: "Research internship, Digital University Kerala (Jan 2026 to May 2026)",
  problem:
    "Airborne LiDAR surveys measure forest canopy height accurately but are expensive to repeat.",
  solution:
    "Hybrid deep learning models (U-Net and Vision Transformer) that predict canopy height from aerial RGB imagery.",
  contribution:
    "Developed, trained and evaluated the models in Python and PyTorch, using LiDAR-derived Canopy Height Models from the NEON dataset as ground truth.",
  outcome: "RMSE of 2.43 m and R² of 0.88, showing a scalable alternative to airborne LiDAR surveys.",
  tech: ["Python", "PyTorch", "U-Net", "Vision Transformer", "NEON dataset"],
  metrics: [
    { label: "RMSE", value: "2.43 m" },
    { label: "R²", value: "0.88" },
  ],
};

export const projects = [
  {
    name: "Credit Card Complaints Dashboard",
    year: "2025",
    problem: "Complaint data across billing disputes, fraud and resolution was hard to track at a glance.",
    solution: "An interactive Tableau dashboard over 86,893 complaints with KPIs and state-wise complaint density across the US.",
    outcome: "Timely response rate of 98.90%, closed complaint rate of 59.92%, and visibility across 5+ submission channels.",
    tech: ["Tableau", "Data Visualization", "KPI Design"],
    link: "https://github.com/nehasanjay2003/Credit-Card-Complaints-Dashboard",
  },
  {
    name: "Healthcare Analytics Dashboard",
    year: "2026",
    problem: "Patient, encounter, diagnosis and procedure data needed to become actionable healthcare insight.",
    solution: "An interactive dashboard on SQL Server and Power BI with KPI cards, charts and slicers.",
    outcome: "A single view for exploring patient and procedure data by slicer.",
    tech: ["SQL Server", "Power BI", "SQL"],
    link: "https://github.com/nehasanjay2003/Healthcare-Analytics-Dashboard",
  },
  {
    name: "Smart Waste Segregation and Monitoring",
    year: "2025",
    problem: "Waste sorting and monitoring is manual and hard to track.",
    solution: "A CNN classifier built with TensorFlow and Keras, with real-time monitoring and automated alerts.",
    outcome: "95.99% validation accuracy.",
    tech: ["TensorFlow", "Keras", "CNN"],
    link: "https://github.com/nehasanjay2003/waste-system",
  },
];

export const experience = [
  {
    role: "Research Intern",
    org: "Digital University Kerala, Thiruvananthapuram",
    dates: "Jan 2026 to May 2026",
    points: [
      "Developed U-Net and Vision Transformer models for forest canopy height estimation from aerial RGB imagery.",
      "Trained and evaluated models against LiDAR-derived Canopy Height Models from the NEON dataset using Python and PyTorch.",
      "Reached RMSE 2.43 m and R² 0.88, a scalable alternative to airborne LiDAR surveys.",
    ],
  },
];

export const skills = [
  { group: "Languages and query", items: ["Python", "SQL", "R"] },
  { group: "Analysis", items: ["Pandas", "NumPy", "Data Cleaning", "Data Validation", "EDA", "Statistical Analysis"] },
  { group: "Machine learning", items: ["PyTorch", "TensorFlow", "Keras", "Model Training", "Model Evaluation"] },
  { group: "BI and databases", items: ["Power BI", "Tableau", "MS Excel", "Microsoft SQL Server"] },
  { group: "Working style", items: ["Analytical Thinking", "Problem-Solving", "Attention to Detail", "Communication", "Teamwork"] },
];

export const education = [
  { name: "M.Sc. Data Science and Analytics", org: "Mahatma Gandhi University, Kottayam", dates: "2024 to 2026", note: "Graduated with 85%, 4th position in program" },
  { name: "B.Sc. Mathematics", org: "Catholicate College, Pathanamthitta", dates: "2021 to 2024", note: "Mathematics and Statistics" },
];

export const certifications = [
  { name: "Data Analytics with Python", org: "NPTEL", year: "2024" },
  { name: "Excel Basics for Data Analysis", org: "IBM (Coursera)", year: "2025" },
  { name: "Statistical Computing and Data Analysis", org: "MG University", year: "2023" },
];
